package TicTacToeGame;

import java.util.Random;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author clatulip
 */
public class GameDataModel {
    private Player p1;
    private Player p2;
    private int numPlayers = 0;
    private boolean gameStarted = false;
    private boolean gameOver = false;
    final private int MAX_ROUNDS = 7;
    private int round = 0;
    private boolean twoPlayers;
    private boolean gameModeSelected = false;
    private boolean p1Turn;
    private Win win = Win.NONE;
    private int counter = 0;
    private boolean tie = false; 
    public int p1Win = 0;
    public int p2Win = 0;
    public int currentRound = 0;
    //parralel 2d array to compare with win cons cause im lazy;
    public final int[][] winCon = {{-1,-1,-1}, {0 ,1 ,2}, {3, 4, 5}, {6, 7, 8}, {0, 3, 6}, {1, 4, 7}, {2, 5, 8}, {0, 4, 8}, {2, 4, 6}};
    
    private Token[] gameArray = new Token[9];

    
    public int getMAX_ROUNDS() {
        return MAX_ROUNDS;
    }

    public int getRound() {
        return round;
    }

    public void setRound(int round) {
        if (round <= MAX_ROUNDS)
            this.round = round;
    }

    public Token[] getGameArray() {
        return gameArray;
    }

    public void setGameArray(Token[] gameArray) {
        this.gameArray = gameArray;
    }
    
    
    

    public Player getP1() {
        return p1;
    }

    public void setP1(Player p1) {
        this.p1 = p1;
    }

    public Player getP2() {
        return p2;
    }

    public void setP2(Player p2) {
        this.p2 = p2;
    }
    

    public boolean isGameStarted() {
        return gameStarted;
    }

    public void setGameStarted(boolean gameStarted) {
        this.gameStarted = gameStarted;
    }

    public boolean isTie() {
        return tie;
    }

    public boolean isGameOver() {
        return gameOver;
    }

    public void setGameOver(boolean gameOver) {
        this.gameOver = gameOver;
    }

    public boolean isTwoPlayers() {
        return twoPlayers;
    }

    public void setTwoPlayers(boolean twoPlayers) {
        this.twoPlayers = twoPlayers;
        this.gameModeSelected = true;
    }

    void addNewPlayer(String name) {
        if (numPlayers == 0) {
            p1 = new Player(name);
            numPlayers += 1;
        } else if (numPlayers == 1) {
            p2 = new Player(name);
            numPlayers += 1;
        } else {
            System.out.println("Shouldn't get here - trying to add more than one player");
        }
    }

    public boolean isGameReady() {
        // check to see if players have been set up
        boolean ready = false;
        if (twoPlayers == false) {
            if (p1 != null) {
                p2 = new Player("Computer");
                numPlayers++;
                ready = true;
            }
        } else  {
            if ((p1 != null) && (p2 != null)) {
                ready = true;
            }
        }
        return ready;
    }

    public boolean selectedGameMode() {
       return gameModeSelected;
    }
    
    public void startGame() {
        gameStarted = true;
        startNewRound();
    }
    
    public void startNewRound() {
        tie = false;
        //increment round and reset counter for tie check
        currentRound++;
        counter =0;
        gameOver = false;
        p1Turn = true;
        win = Win.NONE;
        if (twoPlayers) {
            double temp = Math.random();
            if (temp > 0.5) {
                p1Turn = false;
                System.out.println("P2 goes first.");
            } else {
                System.out.println("P1 goes first");
            }
        }
        
        for (int i = 0; i< 9; i++) {
            gameArray[i] = Token.Blank;      
        }
        
        
        GameBoard myGameBoard = new GameBoard(this);
        myGameBoard.setVisible(true);
    }
    
    public boolean changeToken(int index) {
        // make sure this space is blank, if not return
        
        if (gameArray[index] != Token.Blank) {
            System.out.println("Space is already used");
            return false;
        }
        
        // get token for player
        Token t;
        if (p1Turn) {
            t = Token.X;
        } else {
            t = Token.O;
        }
        
        // set token at index
        gameArray[index] = t;
        
        System.out.println("changes token");
        int check = checkForWin(index);
        // see if won, if so, game is over and return true
        if (check == 1) {
            
            System.out.println("Wins!");
            gameOver = true;
            return true;
        }
        else if(check == 0){
            gameOver = true; 
            tie = true;
            return true;
        }
        
        // change turns
        p1Turn = !p1Turn;
        return true;
    }
    
    
    public boolean isSpaceBlank(int index) {
        if (gameArray[index] == Token.Blank) {
            return true;
        } else {
            return false;
        }
    }
    
    public boolean isP1Turn() {
        return p1Turn;
    }
    
    public int checkForWin(int index) {
      counter++;
        //this is so stupid its just if statements thats the most effenct way to do this
       
        int j = -1;
        
        if(index < 3){
            j = 0;
        }
        else if( index < 6 ){
           j = 3;
        }
        else{
            j = 6;
        }
        
        Token hold = gameArray[index];
        //horizontal checks
        if(gameArray[j].equals(gameArray[j+1]) && gameArray[j].equals(gameArray[j+2])){
            //to know which win con
            switch(j){
                case 0:
                     this.win = Win.TOP_ROW;
                     break;
                case 3:
                     this.win = Win.MID_ROW;
                     break;
                case 6:
                     this.win = Win.BOT_ROW;
                     break;
            }
            
            return 1;
        }
        
        //vertical check
        
        if (index ==0 || index == 3 || index == 6 ){
            j = 0;
        }
        else  if(index == 1 || index == 4 || index == 7){
            j = 1;
        }
        else{
            j = 2;
        }
        
         if(gameArray[j].equals(gameArray[j+3]) && gameArray[j].equals(gameArray[j+6])){
             //for determining winnning move
             //vertical win cons
             switch(j){
                 case 0:
                     this.win = Win.LEFT_COL;
                     break;
                 case 1:
                      this.win = Win.MID_COL;
                      break;
                 case 2:
                      this.win = Win.RIGHT_COL;
                      break;
             }
            
            return 1;
        }
         //is middle equal
         if(gameArray[4].equals(gameArray[index])){
             if(gameArray[index].equals(gameArray[0]) && gameArray[index].equals(gameArray[8])){
              this.win = Win.DIAG1;
                 return 1;
             }
         
             else if(gameArray[index].equals(gameArray[2]) && gameArray[index].equals(gameArray[6])){
                 this.win = Win.DIAG2;
                 return 1;
                 
             }
         }
         //cant be diag
        
            
             
            
   
        
        
        
        if(counter >= 9){
        return 0;
        }
        return -1;
        
    }

    Token getToken(int i) {
        return gameArray[i];
    }
    
    public Win getWin() {
        return win;
    }
   
    }


enum Token { X, O, Blank};
//win cons
enum Win {NONE, TOP_ROW, MID_ROW, BOT_ROW, LEFT_COL, MID_COL, RIGHT_COL, DIAG1, DIAG2};





