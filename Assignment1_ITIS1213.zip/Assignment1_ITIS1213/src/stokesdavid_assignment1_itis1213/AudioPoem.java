/*
David Stokes
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package StokesDavid_Assignment1_ITIS1213;

import BookClasses.Sound;
import java.util.Random;

/**
 * This class contains methods for mixing up the words in an audio file and
 * creating sound poetry out of them. It contains many stub methods which need
 * to be completed as part of Assignment 1.
 *
 * @author clatulip, (David Stokes)
 */
public class AudioPoem {

    static final int MAX_NUM_WORDS = 100;
    static private Sound[] myWordArray = new Sound[MAX_NUM_WORDS];
    final static int SAMPLE_RATE = 22050;
    static private int numWords = 0;
    static int[] doubletSize = new int[3];

    public AudioPoem(Sound originalSource, int[] spliceArray, int numSplicePoints) {

        // break the sound into sepearate words, copying each into the word array
        for (int i = 0, j = 0; i < numSplicePoints; i = i + 2, j++) {
            myWordArray[j] = new Sound(spliceArray[i + 1] - spliceArray[i]);
            for (int x = spliceArray[i], y = 0; x < spliceArray[i + 1]; x++, y++) {
                myWordArray[j].setSampleValueAt(y, originalSource.getSampleValueAt(x));
            }
            numWords++;
        }

    }

    /**
     * Plays the words, in order with a 200 millisecond pause between each
     *
     * @throws InterruptedException
     */
    public void play() throws InterruptedException {
        // play the words in order
        for (int i = 0; i < numWords; i++) {
            myWordArray[i].blockingPlayOld();
            Thread.sleep(200);
        }
    }

    /**
     * Plays the words, in order with a parameter-specified pause between each
     *
     * @param pause the number of milliseconds to pause between words
     * @throws InterruptedException
     */
    public void play(int pause) throws InterruptedException {
        //iterate through the myWordArray
        for (int i = 0; i < numWords; i++) {
            myWordArray[i].blockingPlayOld();
            Thread.sleep(pause * 1000);
        }

    }

    /**
     * Plays the words, in order with a parameter-specified pause between each
     * and writes the resulting sound out to a file
     *
     * @param pause the number of milliseconds to pause between words
     * @param filename the name of the file to write
     * @param path the path where the file should be written
     * @throws InterruptedException
     */
    public void play(int pause, String filename, String path) throws InterruptedException {
        double time;
        int x = 0;
        //sampling rate
        time = myWordArray[x].getSamplingRate();

        //the number of spaces in a word
        int numBreaks = numWords - 1;
        double silentDuration = (pause * time);
        int liveAudioLengthTotal = 0;
        for (int j = 0; j < numWords; j++) {
            liveAudioLengthTotal += myWordArray[j].getLength();

        }
        //the new sound file
        int pastSoundSize = 0;
        double totalSize = liveAudioLengthTotal + (silentDuration * numBreaks);
        Sound copy = new Sound((int) totalSize);
        //iterate through and set sample values at
        int i = 0;
        for (int z = 0; z < numWords; z++) {
            //the word portion
            for (int j = 0; j < myWordArray[z].getLength(); j++) {
                copy.setSampleValueAt(i, myWordArray[z].getSampleValueAt(j));
                i++;
            }
            //silent portion
            if (z != numWords - 1) {
                for (int k = 0; k < ((int) silentDuration); k++) {
                    copy.setSampleValueAt(i, 0);
                    i++;
                }
            }
        }
        copy.play();
        copy.write(path + filename);
    }

    //iterate through this
    /**
     * Plays the words in random order, each word can be played multiple times
     *
     * @param totalWords the total number of words that will be played
     * @param pause the number of seconds to pause between words
     * @throws InterruptedException
     */
    //FIXME no pause between first and second
    public void playRandomOrder(int totalWords, int pause) throws InterruptedException {
        Random rand = new Random();

        //sound object of length that is empty
        Sound empty = this.makeSilent(pause, myWordArray[0]);

        for (int i = 0; i < totalWords; i++) {
            //generatre random num between 0 and numWOrds non inclusive
            int current = rand.nextInt((numWords));

            myWordArray[current].blockingPlayOld();
            empty.blockingPlayOld();

        }

    }

    /**
     * Plays the words in random order, each word can be played multiple times
     * and then writes the resulting sound to a .wav file
     *
     * @param totalWords totalWords the total number of words that will be
     * played
     * @param pause the number of seconds to pause between words
     * @param filename the name of the file to write
     * @param path the path where the file should be written
     */
    public void playRandomOrder(int totalWords, int pause, String filename, String path) {
        Random rand = new Random();
        Sound empty = this.makeSilent(pause, myWordArray[0]);
        int first = 7700;
        int second = 11100;
        int third = 7700;
        int fourth = 9800;
        int[] array = new int[totalWords];

        //gen random numbers and store in array
        for (int i = 0; i < totalWords; i++) {
            array[i] = rand.nextInt((numWords));
        }

        //the total size of the live audio and 1 less than total words of silence
        int size = 0;
        size = size + (empty.getLength() * (totalWords - 1));

        //generate random value 0 -3 for each element 
        int count0 = 0;
        int count1 = 0;
        int count2 = 0;
        int count3 = 0;
        for (int i = 0; i < totalWords; i++) {
            int x = rand.nextInt(3);
            //stores in an array
            array[i] = x;

            //increment a variable that represents each word depending on the value of that random value
            switch (x) {
                case 0:
                    count0++;
                    break;
                case 1:
                    count1++;
                    break;
                case 2:
                    count2++;
                    break;
                case 3:
                    count3++;
                    break;
            }
        }
        //multiply the number of times each word is played and multiply this by each words size then summate them
        int live = count0 * first;
        live = live + count1 * second;
        live = live + count2 * third;
        live = live + count3 * fourth;

        //the total size of the new sound object
        int total = live + size;

        //new object that will be writtern
        Sound copy = new Sound(total);

        int j = 0;
        int counter = 0;
        //iterate through the random array
        for (int a = 0; a < totalWords; ++a) {
            //the switch takes in the values held in the random gened array from above
            switch (array[a]) {
                //populate the new sound object based on the random generation from earlier in the code
                case 0:
                    for (int z = 0; z < first; z++) {

                        copy.setSampleValueAt(j++, myWordArray[0].getSampleValueAt(z));

                    }
                    counter++;
                    break;
                case 1:
                    for (int z = 0; z < second; z++) {

                        copy.setSampleValueAt(j++, myWordArray[1].getSampleValueAt(z));

                    }
                    counter++;
                    break;
                case 2:
                    for (int z = 0; z < third; z++) {

                        copy.setSampleValueAt(j++, myWordArray[2].getSampleValueAt(z));

                    }
                    counter++;
                    break;
                case 3:
                    for (int z = 0; z < fourth; z++) {

                        copy.setSampleValueAt(j++, myWordArray[3].getSampleValueAt(z));

                    }
                    counter++;
                    break;

            }
            //adds silent portion and stop from adding sound to end of sound file
            if (counter < totalWords) {
                for (int k = 0; k < empty.getLength(); k++) {
                    copy.setSampleValueAt(j++, 0);
                }
            }

        }
        //play and write it
        copy.play();
        copy.write(path + filename);

    }

    /**
     * Plays the words in random order, playing each word only once
     *
     * @param pause the number of seconds to pause between words
     * @throws InterruptedException
     */
    public void playRandomUnique(int pause) throws InterruptedException {

        Random random = new Random();
        //the silent portions and size
        Sound quiet = this.makeSilent(pause, myWordArray[0]);
        int[] values = new int[numWords];
        for (int i = 0; i < numWords; i++) {
            values[i] = random.nextInt(numWords);
            for (int a = 0; a < i; a++) {
                if (values[i] == values[a]) {
                    i--;

                }
            }
        }

        for (int i = 0; i < numWords; i++) {

            myWordArray[values[i]].blockingPlayOld();
            quiet.blockingPlayOld();
        }

    }

    /**
     * Plays the words in random order, playing each word only once and then
     * writes the resulting sound to a file
     *
     * @param pause the number of seconds to pause between words
     * @param filename the name of the file to write
     * @param path the path where the file should be written
     */
    public void playRandomUnique(int pause, String filename, String path) {
        Random rand = new Random();
        Sound empty = this.makeSilent(pause, myWordArray[0]);

        //get size of new sound object
        //each word has its own size so they need to be accounted for
        int first = 7700;
        int second = 11100;
        int third = 7700;
        int fourth = 9800;
        int live = first + second + third + fourth;
        int size = 0;
        size = size + (empty.getLength() * (3));
        int total = live + size;

        Sound copy = new Sound(total);
        //gen random unique order and store in array
        int[] values = new int[numWords];
        for (int i = 0; i < numWords; i++) {
            values[i] = rand.nextInt(numWords);
            for (int a = 0; a < i; a++) {
                if (values[i] == values[a]) {
                    i--;

                }
            }
        }

        int j = 0;
        int counter = 0;
        for (int a = 0; a < numWords; ++a) {
            //iterate trhough the randomly generated array a
            switch (values[a]) {
                // iterates thorugh the word and writes it to the new sound object
                case 0:
                    for (int z = 0; z < first; z++) {

                        copy.setSampleValueAt(j++, myWordArray[0].getSampleValueAt(z));

                    }
                    counter++;
                    break;
                case 1:
                    for (int z = 0; z < second; z++) {

                        copy.setSampleValueAt(j++, myWordArray[1].getSampleValueAt(z));

                    }
                    counter++;
                    break;
                case 2:
                    for (int z = 0; z < third; z++) {

                        copy.setSampleValueAt(j++, myWordArray[2].getSampleValueAt(z));

                    }
                    counter++;
                    break;
                case 3:
                    for (int z = 0; z < fourth; z++) {

                        copy.setSampleValueAt(j++, myWordArray[3].getSampleValueAt(z));

                    }
                    counter++;
                    break;

            }
            //is used to not add a silent at the end of file
            if (counter < numWords) {
                for (int k = 0; k < empty.getLength(); k++) {
                    copy.setSampleValueAt(j++, 0);
                }
            }

        }
        copy.play();
        copy.write(path + filename);
    }

    /**
     * Plays the sound words in reverse order (e.g. 'this is a test' will be
     * played 'test a is this')
     *
     * @param pause the number of seconds to pause between words
     * @throws InterruptedException
     */
    public void playReverseOrder(int pause) throws InterruptedException {
        int counter = 0;
        for (int i = numWords - 1; i >= 0; i--) {
            myWordArray[i].blockingPlay();
            counter++;
            if (counter != numWords) {
                Thread.sleep(pause * 1000);
            }
        }
    }

    /**
     * Plays the sound words in reverse order (e.g. 'this is a test' will be
     * played 'test a is this') and then writes the sound into a new file
     *
     * @param pause the number of seconds to pause between words
     * @param filename the name of the file to write
     * @param path the path where the file should be written
     */
    public void playReverseOrder(int pause, String filename, String path) {
        int size = 0;
        //calculate the size of the new sound object
        for (int i = numWords - 1; i >= 0; i--) {
            size += myWordArray[i].getLength();
            size += this.getSilentLength(pause, SAMPLE_RATE);
        }
        size = size - this.getSilentLength(pause, SAMPLE_RATE);
        Sound copy = new Sound(size);
        //set values at new sound object
        int z = 0;
        int counter = 0;
        for (int i = numWords - 1; i >= 0; i--) {
            //copy over audio from original file for length of the word
            for (int j = 0; j < myWordArray[i].getLength(); j++) {
                copy.setSampleValueAt(z++, myWordArray[i].getSampleValueAt(j));
            }
            counter++;
            if (counter != numWords) {
                //write silence for pause length
                for (int j = 0; j < this.getSilentLength(pause, SAMPLE_RATE); j++) {
                    copy.setSampleValueAt(z++, 0);
                }
            }

        }
        copy.play();
        copy.write(path + filename);
    }

    /**
     * Plays random pairs of consecutive words with only a 100 millisecond pause
     * between them, with a four hundred millisecond pause between pairs Ex: for
     * 'this is a test' a pair would only be 'this is' or 'is a' or 'a test'
     *
     * @param numDoublets the number of doublets to play
     * @throws InterruptedException
     */
    public void playDoublets(int numDoublets) throws InterruptedException {
        Random rand = new Random();
        Sound longQuiet = this.makeSilent(.4, myWordArray[0]);
        
        //create new sound objects usse helper methods for code compartmentalization
        Sound one = this.doubletOne();
        Sound two = this.doubletTwo();
        Sound three = this.doubletThree();

        for (int i = 0; i < numDoublets; i++) {
            int x = rand.nextInt(3);
            //generate then play
            switch (x) {
                case 0:
                    one.blockingPlayOld();
                    break;
                case 1:
                    two.blockingPlayOld();
                    break;
                default:
                    three.blockingPlayOld();
                    break;
            }
            //the 400 ms pause after a doublet
            longQuiet.blockingPlayOld();

        }
    }

    /**
     * Plays random pairs of consecutive words with only a 100 millisecond pause
     * between them, with a four hundred millisecond pause between pairs Ex: for
     * 'this is a test' a pair would only be 'this is' or 'is a' or 'a test' and
     * then writes the resulting audio to a new file
     *
     * @param numDoublets number of doublets to be played
     * @param filename the name of the file to write
     * @param path the path where the file should be written
     */
    public void playDoublets(int numDoublets, String filename, String path) {
        final int flag = numDoublets;
        Random rand = new Random();
        Sound longQuiet = this.makeSilent(.4, myWordArray[0]);
        int size = 0;

        //gen random numbers first due to differing sizes
        Sound one = this.doubletOne();
        Sound two = this.doubletTwo();
        Sound three = this.doubletThree();

        //calculutes the occurence of each double
        int count0 = 0;
        int count1 = 0;
        int count2 = 0;
        int[] roll = new int[numDoublets];
        for (int i = 0; i < numDoublets; i++) {
            int x = rand.nextInt(3);
            roll[i] = x;
            switch (x) {
                case 0:
                    count0++;
                    break;
                case 1:
                    count1++;
                    break;
                case 2:
                    count2++;
                    break;
            }
        }
        //multiplies size of each doublet by the occurences calculuted above
        int live = count0 * doubletSize[0];
        live = live + count1 * doubletSize[1];
        live = live + count2 * doubletSize[2];

        //get size of the silent portions
        int silent = (this.getSilentLength(.4, SAMPLE_RATE)) * (numDoublets - 1);

        //calcuates the silent and live audio to overall size and then initializes and new sound object of that size
        size = live + silent;
        Sound copy = new Sound(size);

        //external counters
        //j is the overall index of copy
        int j = 0;
        //used for not adding silence after the last word
        int counter = 0;

        //iterated thorough doublets
        for (int a = 0; a < numDoublets; ++a) {
            //use previsoubly generated random numbers and feed into switch to populate the new object
            switch (roll[a]) {
                case 0:
                    for (int z = 0; z < one.getLength(); z++) {

                        copy.setSampleValueAt(j++, one.getSampleValueAt(z));

                    }
                    counter++;
                    break;
                case 1:
                    for (int z = 0; z < two.getLength(); z++) {

                        copy.setSampleValueAt(j++, two.getSampleValueAt(z));

                    }
                    counter++;
                    break;
                case 2:
                    for (int z = 0; z < three.getLength(); z++) {

                        copy.setSampleValueAt(j++, three.getSampleValueAt(z));

                    }
                    counter++;
                    break;
            }
            //if not the last word iteralte thrugh the object for the length of the silence and set the sample value to zero
            if (counter < flag) {
                for (int k = 0; k < longQuiet.getLength(); k++) {
                    copy.setSampleValueAt(j++, 0);

                }
                //code gets cranky if i get rid of the else idk...
            } else {

            }

        }

        copy.play();

        copy.write(path + filename);

    }

    /**
     * Creates a sound object based on the sample rate of original and desired
     * pause time
     *
     * @param pause the number of seconds to pause between words
     * @param rate original sound object
     * @return empty sound object
     */
    private Sound makeSilent(double pause, Sound rate) {

        //double sampleRate = rate.getSamplingRate();
        double sampleRate = SAMPLE_RATE;

        double total = (sampleRate * (pause));
        //ceil used to ensure enough size is allocated 
        Sound silent = new Sound((int) (Math.ceil(total)));

        for (int i = 0; i < total; i++) {
            silent.setSampleValueAt(i, 0);

        }

        return silent;

    }

    /**
     *
     * @param pause
     * @param sampleRate
     * @return the size of the value
     */
    private int getSilentLength(double pause, int sampleRate) {
        //ceil used to ensure enough space allocation
        int total = (int) (Math.ceil((sampleRate * pause)));
        return total;
    }

    /**
     * creates a doublet sound object with " this is" with a pause between
     * letters
     *
     * @return @see Sound
     */
    private Sound doubletOne() {

        int totalLength = ((myWordArray[0].getLength()) + this.getSilentLength(.1, SAMPLE_RATE) + (myWordArray[1].getLength()));
        doubletSize[0] = totalLength;
        Sound one = new Sound(totalLength);
        int i = 0;
        //first word
        for (int j = 0; j < myWordArray[0].getLength(); j++) {
            one.setSampleValueAt(i, myWordArray[0].getSampleValueAt(j));
            i++;
        }
        //silent
        for (int j = 0; j < this.getSilentLength(.1, SAMPLE_RATE); j++) {
            one.setSampleValueAt(i, 0);
            i++;
        }
        //second word
        for (int j = 0; j < myWordArray[1].getLength(); j++) {
            one.setSampleValueAt(i, myWordArray[1].getSampleValueAt(j));
            i++;
        }
        return one;
    }

    /**
     * creates a doublet sound object with " is a" with a pause between letters
     *
     * @return @see Sound
     */
    private Sound doubletTwo() {

        int totalLength = ((myWordArray[1].getLength()) + this.getSilentLength(.1, SAMPLE_RATE) + (myWordArray[2].getLength()));
        doubletSize[1] = totalLength;
        Sound two = new Sound(totalLength);
        int i = 0;
        //first word
        for (int j = 0; j < myWordArray[1].getLength(); j++) {
            two.setSampleValueAt(i, myWordArray[1].getSampleValueAt(j));
            i++;
        }
        //silent
        for (int j = 0; j < this.getSilentLength(.1, SAMPLE_RATE); j++) {
            two.setSampleValueAt(i, 0);
            i++;
        }
        //second word
        for (int j = 0; j < myWordArray[2].getLength(); j++) {
            two.setSampleValueAt(i, myWordArray[2].getSampleValueAt(j));
            i++;
        }
        return two;
    }

    /**
     * creates a doublet sound object with " a test" with a pause between
     * letters
     *
     * @return @see Sound
     */
    private Sound doubletThree() {

        int totalLength = ((myWordArray[2].getLength()) + this.getSilentLength(.1, SAMPLE_RATE) + (myWordArray[3].getLength()));
        doubletSize[2] = totalLength;
        Sound three = new Sound(totalLength);
        int i = 0;
        //first word
        for (int j = 0; j < myWordArray[2].getLength(); j++) {
            three.setSampleValueAt(i, myWordArray[2].getSampleValueAt(j));
            i++;
        }
        //silent
        for (int j = 0; j < this.getSilentLength(.1, SAMPLE_RATE); j++) {
            three.setSampleValueAt(i, 0);
            i++;
        }
        //second word
        for (int j = 0; j < myWordArray[3].getLength(); j++) {
            three.setSampleValueAt(i, myWordArray[3].getSampleValueAt(j));
            i++;
        }
        return three;
    }

    /**
     * Generates random combination of words like the random unique method and then checks the audio sample values and displays the words played in order
     *
     */
    public void audioToText() {
        //gen arrays ofeach size of word the firwst array has weird capilitaziation as this is a reserved word
        int[] thiS = new int[myWordArray[0].getLength()];
        int[] is = new int[myWordArray[1].getLength()];
        int[] a = new int[myWordArray[2].getLength()];
        int[] test = new int[myWordArray[3].getLength()];

        //populate array of each word
        for (int i = 0; i < myWordArray[0].getLength(); i++) {
            thiS[i] = myWordArray[0].getSampleValueAt(i);
        }
        for (int i = 0; i < myWordArray[1].getLength(); i++) {
            is[i] = myWordArray[1].getSampleValueAt(i);
        }
        for (int i = 0; i < myWordArray[2].getLength(); i++) {
            a[i] = myWordArray[2].getSampleValueAt(i);
        }
        for (int i = 0; i < myWordArray[3].getLength(); i++) {
            test[i] = myWordArray[3].getSampleValueAt(i);
        }
       
        Random random = new Random();
        //creates silent sound object
        Sound quiet = this.makeSilent(1, myWordArray[0]);
        int[] values = new int[numWords];
        //generate random unique order to play the words in from the playRandomUnique method this is stored in an array
        for (int i = 0; i < numWords; i++) {
            values[i] = random.nextInt(numWords);
            for (int j = 0; j < i; j++) {
                if (values[i] == values[j]) {
                    i--;

                }
            }
        }
        //play the sound
        for (int i = 0; i < numWords; i++) {

            myWordArray[values[i]].blockingPlayOld();
            quiet.blockingPlayOld();
        }
        //iterate through this is the outter loop which iterates through each word
        for (int j = 0; j < numWords; j++) {
            //booleans reset
            boolean zero, one, two, three;
            zero = true;
            one = true;
            two = true;
            three = true;
            //checks through each index of the word and compares with test samples to find equivalence
            for (int i = 0; i < myWordArray[values[j]].getLength(); i++) {
                if (zero || one || two || three) {
                    if (zero && !(thiS[i] == myWordArray[values[j]].getSampleValueAt(i))) {
                        zero = false;
                    }
                    if (one && !(is[i] == myWordArray[values[j]].getSampleValueAt(i))) {
                        one = false;
                    }
                    if (two && !(a[i] == myWordArray[values[j]].getSampleValueAt(i))) {
                        two = false;
                    }
                    if (three && !(test[i] == myWordArray[values[j]].getSampleValueAt(i))) {
                        three = false;
                    } else {
                        break;
                    }

                }
            }
            //output is determined by booleans set using loop and conditionals
            if (zero) {
                System.out.print("this ");
            } else if (one) {
                System.out.print("is ");
            } else if (two) {
                System.out.print("a ");
            } else if (three) {
                System.out.print("test ");
            }
        }

    }

}
