/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package woffortune;

import java.util.ArrayList;

/**
 * Class that defines a player for a game with monetary winnings and 
 * a limited number of choices
 * @author clatulip
 */
public class Player {
    private int winnings = 0; // amount of money won
    private int bankedWinnings = 0;
    private String name; // player's name
    private int numGuesses = 0; // number of times they've tried to solve puzzle
    private ArrayList<Prizes> wonPrizes = new ArrayList<>();
    private ArrayList<Prizes> bankedPrizes = new ArrayList<>();
    /**
     * Constructor
     * @param name String that is the player's name
     */
    public Player(String name) {
        this.name = name;
    }

    public ArrayList<Prizes> getWonPrizes() {
        return wonPrizes;
    }

    public void setWonPrizes(Prizes i) {
        wonPrizes.add(i);
    }
    
    

    /**
     * Getter
     * @return int amount of money won so far 
     */
    public int getWinnings() {
        return winnings;
    }

    /**
     * Adds amount to the player's winnings
     * @param amount int money to add
     */
    public void incrementScore(int amount) {
        if (amount < 0) return;
        this.winnings += amount;
    }

    /**
     * Getter 
     * @return String player's name 
     */
    public String getName() {
        return name;
    }

    /**
     * Getter
     * @return int the number of guesses used up 
     */
    public int getNumGuesses() {
        return numGuesses;
    }

    /** 
     * Add 1 to the number of guesses used up
     */
    public void incrementNumGuesses() {
        this.numGuesses++;
    }
    
    /**
     * Resets for a new game (only number of guesses)
     * This does not reset the winnings.
     */
    public void reset() {
        this.numGuesses = 0;
    }
    
    public void bankrupt() {
        this.winnings = 0;
        //clear prizes as well
        for(int i = 0; i < wonPrizes.size(); i++){
            wonPrizes.remove(i);
            
        }
    }
    //display the total winnings including prizes
    public void endDisplay(){
        System.out.println(name);
        System.out.println("Money Won: " + winnings);
        for (int i = 0; i < wonPrizes.size(); i++) {
            System.out.println("prize: " + wonPrizes.get(i).printAll());
            
        }
    }
    
    public void bank(){
        //store winings from last round
        bankedWinnings = winnings;
        
        //reset gueses
        this.reset();
        
         for(Prizes i: wonPrizes){
           bankedPrizes.add(i);
         }
         //uses to zero out balance and prizes won 
         this.bankrupt();
        
        //
        
        
    }
    
    public void printBank(){
        
        System.out.println(name);
        
        System.out.println(bankedWinnings + "$");
        
        for(Prizes i: bankedPrizes){
            i.printAll();
        }
        
        
        
    }
    
    
    
    
}
