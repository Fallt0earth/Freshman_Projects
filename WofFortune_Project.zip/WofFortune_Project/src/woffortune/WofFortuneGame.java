/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package woffortune;

import java.util.ArrayList;
import java.util.Random;
import java.util.Scanner;

/**
 * WofFortuneGame class
 * Contains all logistics to run the game
 * @author clatulip && David Stokes
 */
public class WofFortuneGame {

    private boolean puzzleSolved = false;

    private Wheel wheel;
    //private Player player1;
    private String phrase = "Once upon a time";
    private ArrayList<Letter> allLetters = new ArrayList<>();
    private ArrayList<String> phrases = new ArrayList<>();
    private ArrayList<Player> players = new ArrayList<>();
    private ArrayList<Prizes> prizes = new ArrayList<>();
    
    
    

    /**
     * Constructor
     * @param wheel Wheel 
     * @throws InterruptedException 
     */
    public WofFortuneGame(Wheel wheel) throws InterruptedException {
        // get the wheel
        this.wheel = wheel;
      
        // do all the initialization for the game
        setUpGame();
        

    }
    
    /**
     * Plays the game
     * @throws InterruptedException 
     */
    public void playGame() throws InterruptedException {
        //FIXME does not alternate turns correctly when player los3s turn
        // while the puzzle isn't solved, keep going
        //for (int i = 0; i < players.size(); i++) {
        int i = 0;
            while (!puzzleSolved){
            // let the current player play
            
            //catch intterupted
            try{
                //players turn
            playTurn(players.get(i));
            }
            catch(InterruptedException e){
                    System.out.println("Interrupted exception in the play turn method: " + e );
                    }
            
            
            i++;
            if (i == players.size()){
                //reset if all players have gone
                i = 0;
            }
            
        //}
        }
    }
    
    /**
     * Sets up all necessary information to run the game
     */
    private void setUpGame() {
         Scanner input = new Scanner(System.in);
        this.populatePhrase();
        this.populatePrizes();
        // create a single player 
        //player1 = new Player("Player1");
        //Scanner input = new Scanner(System.in);
        
        System.out.println("How many players do you want to play?");
        int numPlayers = 1;
        
        //loop if the user does not enter an int
        boolean flag = true;
        while(flag){
        try{
        
        numPlayers = input.nextInt();
        input.nextLine();
        flag = false;
        }
         catch(Exception e){
            System.out.println("error of type" + e);
             System.out.println("Please enter an integer");
             System.out.println("How many players do you want to play");
             input.nextLine();
        }
        }
        
         
        String name = "";
        try{
        for (int i = 1; i <= numPlayers; i++) {
            System.out.println("What is the new players name?");
            
            //FIXME exectutes immedietly
        //FIXME no way to use nextLine
        
            name = input.nextLine();
        
            players.add(new Player(name));
        }
        }
        catch(Exception e){
            System.out.println("error of type" + e);
        }
        
        
        for(Player i: players){
            System.out.println(i.getName());
        }
        
        // print out the rules
        System.out.println("RULES!");
        System.out.println("Each player gets to spin the wheel, to get a number value");
        System.out.println("Each player then gets to guess a letter. If that letter is in the phrase, ");
        System.out.println(" the player will get the amount from the wheel for each occurence of the letter");
        System.out.println("If you have found a letter, you will also get a chance to guess at the phrase");
        System.out.println("Each player only has three guesses, once you have used up your three guesses, ");
        System.out.println("you can still guess letters, but no longer solve the puzzle.");
        
        boolean run = true;
        while(run){
        System.out.println("Would you like to input a custom word? Y/N");
        System.out.println();
        char choice = 'a';
        try{
            
        //does user want a custom phrase
        choice = input.next().charAt(0);
        input.nextLine();
        
        }
         catch(Exception e){
            System.out.println("error of type" + e);
        }
        if (choice == 'Y' || choice == 'y'){
            
        run = false;
            System.out.println("What is your custom phrase");
            try{
        this.phrase = input.nextLine();
            }
             catch(Exception e){
            System.out.println("error of type" + e);
        }
        }
        //user does not want use default phrases
        else if (choice == 'N' || choice == 'n'){
            
                run = false;
            
                //pick random phrase from list
            Random rand = new Random();
            int z = rand.nextInt(phrases.size());
            this.phrase = phrases.get(z);
            System.out.println("Ok, lets Start!");
            
        }
        else{
            System.out.println("please enter Y / N. Your input was not correct");
        }
        }
        
        
        // for each character in the phrase, create a letter and add to letters array
        for (int i = 0; i < phrase.length(); i++) {
            allLetters.add(new Letter(phrase.charAt(i)));
        }
        
        // setup done
        
       
    }
    
    /**
     * One player's turn in the game
     * Spin wheel, pick a letter, choose to solve puzzle if letter found
     * @param player
     * @throws InterruptedException 
     */
    private void playTurn(Player player) throws InterruptedException {
        while(true) {
        int money = 0;
        Scanner sc = new Scanner(System.in);
        
        //the swhille is spaun
        System.out.println(player.getName() + ", you have $" + player.getWinnings());
        System.out.println("Spin the wheel! <press enter>");
        sc.nextLine();
        System.out.println("<SPINNING>");
        Thread.sleep(200);
        Wheel.WedgeType type = wheel.spin();
        System.out.print("The wheel landed on: ");
        //for determinging winngs later
        boolean isPrize = false;
        //placeholder prize object
        Prizes prize = new Prizes("null" , 0);
        
        //switch for spin of wheel and what happens
        switch (type) {
            case MONEY:
                money = wheel.getAmount();
                System.out.println("$" + money);
                break;
            
                
            case LOSE_TURN:
                System.out.println("LOSE A TURN");
                System.out.println("So sorry, you lose a turn.");
                return; // doesn't get to guess letter
                
                
            case BANKRUPT:
                System.out.println("BANKRUPT");
                player.bankrupt();
                return; // doesn't get to guess letter
                
            case PRIZE:
                isPrize = true;
                System.out.println("PRIZE");
                int index = prizeSpin();
                
                prize = prizes.get(index);
                //takes the prize out of the prize table
                prizes.remove(index);
                System.out.println(player.getName() + " can win " + prize.printAll());
                
                break;
                
                
                
            default:
                
        }
        System.out.println("");
        System.out.println("Here is the puzzle:");
        showPuzzle();
        System.out.println();
        System.out.println(player.getName() + ", please guess a letter.");
        

        
        char letter = 'a';
        try{
        letter = sc.next().charAt(0);
        
        }
         catch(Exception e){
            System.out.println("error of type" + e);
        }
        
        
        if (!Character.isAlphabetic(letter)) {
            System.out.println("Sorry, but only alphabetic characters are allowed. You lose your turn.");
            break;
            
        } else {
            // search for letter to see if it is in
            int numFound = 0;
            for (Letter l: allLetters) {
                if ((l.getLetter() == letter) || (l.getLetter() == Character.toUpperCase(letter))) {
                    l.setFound();
                    numFound += 1;
                }
            }
            
            if (numFound == 0) {
                System.out.println("Sorry, but there are no " + letter + "'s.");
                break;
                
            } else {
                if (numFound == 1) {
                    System.out.println("Congrats! There is 1 letter " + letter + ":");
                } else {
                    System.out.println("Congrats! There are " + numFound + " letter " + letter + "'s:");
                }
                System.out.println();
                showPuzzle();
                System.out.println();
                if(isPrize){
                    
                    System.out.println("Congrats you have won" + prize.printAll());
                   player.setWonPrizes(prize);
                }
                else{
                player.incrementScore(numFound*money);
                System.out.println("You earned $" + (numFound*money) + ", and you now have: $" + player.getWinnings());
                
                }

                System.out.println("Would you like to try to solve the puzzle? (Y/N)");
                try{
                letter = sc.next().charAt(0);
                }
                 catch(Exception e){
            System.out.println("error of type" + e);
        }
                System.out.println();
                if ((letter == 'Y') || (letter == 'y')) {
                    solvePuzzleAttempt(player);
                }
            }
            
            
        }
    
        
    }
    }
    
    /**
     * Logic for when user tries to solve the puzzle
     * @param player 
     */
    private void solvePuzzleAttempt(Player player) {
        
        if (player.getNumGuesses() >= 3) {
            System.out.println("Sorry, but you have used up all your guesses.");
            return;
        }
        
        //get user guess of word
        player.incrementNumGuesses();
        System.out.println("What is your solution?");
        Scanner sc = new Scanner(System.in);
        sc.useDelimiter("\n");
        String guess = "";
        try{
        guess = sc.next();
        }
        catch(Exception e){
            System.out.println("error of type" + e);
        }
        if (guess.compareToIgnoreCase(phrase) == 0) {
            System.out.println("Congratulations! You guessed it!");
            puzzleSolved = true;
            // Round is over. Write message with final stats
            System.out.println(player.getName() + " WINS");
            for(Player i: players){
                i.endDisplay();
                
                System.out.println(i.getNumGuesses());
                
                System.out.println("\n");
                System.out.println("");
                
                
            }
            //display banked values
              System.out.println("Current overall Standings");
             for(Player i: players){
               i.printBank();
             }
            //another round
            char choice = 'n';
            System.out.println("Would you like to play another Round?");
             try{
                choice = sc.next().charAt(0);
                }
                 catch(Exception e){
            System.out.println("error of type" + e);
        }
                System.out.println();
                if ((choice == 'Y') || (choice == 'y')) {
                    //same as starting new game just does not create players
                    newRound();
                    try{
                        
                    //play game
                    playGame();
                    }
                    catch(InterruptedException e){
                        System.out.println("error my dude");
                    }
                
                }
                System.out.println("goodbye");
                System.exit(0);
            // TODO
        } else {
            System.out.println("Sorry, but that is not correct.");
        }
    }
    
    /**
     * Display the puzzle on the console
     */
    private void showPuzzle() {
        System.out.print("\t\t");
        for (Letter l: allLetters) {
            if (l.isSpace()) {
                System.out.print("   ");
            } else {
                if (l.isFound()) {
                    System.out.print(Character.toUpperCase(l.getLetter()) + " ");
                } else {
                    System.out.print(" _ ");
                }
            }
        }
        System.out.println();
        
    }
    
    /**
     * For a new game reset all player's number of guesses to 0
     */
    //THIS WAS EDITED
    public void reset() {
        for(Player i: players){
        i.reset();
    }
    }
    
 /**
  * populates phrases
  */
    private void populatePhrase(){
        
        
        
        phrases.add("Did you ever hear the tragedy");
        phrases.add("of Darth Plagueis The Wise");
        phrases.add("I thought not");
        phrases.add("Its not a story the Jedi would tell you");
        phrases.add(" It's a Sith legend.");
        phrases.add("Have you heard");
        phrases.add("Darth Plagueis was a Dark Lord of the Sith");
        phrases.add("so powerful and so wise");
        phrases.add("he could use the Force to influence the midichlorians to create life");
        phrases.add("He had such a knowledge of the dark side");
        phrases.add("he could even keep the ones he cared about from dying");
        phrases.add("He could actually save people from death?");
        phrases.add("The dark side of the Force");
        phrases.add("is a pathway to many abilities some consider to be unnatural");
        phrases.add("He became so powerful");
        phrases.add("he only thing he was afraid of was losing his power");
        phrases.add("which eventually, of course, he did");
        phrases.add("Unfortunately, he taught his apprentice everything he knew");
        phrases.add("then his apprentice killed him");
        phrases.add("in his sleep");
        phrases.add("Ironic. He could save others from death");
        phrases.add("but not himself");
      
                
    }
    /**
     * populates prizes
     */
    private void populatePrizes(){
        //7 prizes
        prizes.add(new Prizes("Cruise", 1000));
        prizes.add(new Prizes("ferrari", 100000));
        prizes.add(new Prizes("lawn mower", 200));
        prizes.add(new Prizes("Trip to Hawaii", 7000));
        prizes.add(new Prizes("eraser", 1));
        prizes.add(new Prizes("House Remodel", 10000));
        prizes.add(new Prizes("Memes", 1000));
        
    }
    /**
     * generates random number from 0 to 6 exclusive
     * @return int index 
     */
    private int prizeSpin(){
        Random rand = new Random();
        int index = rand.nextInt(7);
        return index;
        
    }
    
    
    /**
     * This is used if players are already created and they want to play again. Logic for resets is included
     */
    private void newRound(){
        
        //reset portions
        puzzleSolved = false;
        phrase = "did not reset";
        
        allLetters.clear();
        Scanner input = new Scanner(System.in);
         
        //store moneyzzzzz
        for(Player i: players){
            i.bank();
        }
        boolean flag = true;
        
        while(flag){
            System.out.println("would you like to change the players? Y/ N");
            
            char choice = 'a';
        try{
            
        
        choice = input.next().charAt(0);
        input.nextLine();
        }
         catch(Exception e){
            System.out.println("error of type" + e);
        }
        boolean trip = true;
        while(trip){
            if(choice == 'Y' || choice == 'y'){
                playerChange();
            }
            else if (choice == 'N' || choice == 'n'){
                System.out.println("okay no changes will be made");
                flag = false;
                break;
            }
            else{
                System.out.println("please enter a valid input");
            }
        }
        }
        
       
         // print out the rules
        System.out.println("RULES!");
        System.out.println("Each player gets to spin the wheel, to get a number value");
        System.out.println("Each player then gets to guess a letter. If that letter is in the phrase, ");
        System.out.println(" the player will get the amount from the wheel for each occurence of the letter");
        System.out.println("If you have found a letter, you will also get a chance to guess at the phrase");
        System.out.println("Each player only has three guesses, once you have used up your three guesses, ");
        System.out.println("you can still guess letters, but no longer solve the puzzle.");
        System.out.println("Would you like to input a custom word? Y/N");
        System.out.println();
        char choice = 'a';
        try{
            
        
        choice = input.next().charAt(0);
        input.nextLine();
        }
         catch(Exception e){
            System.out.println("error of type" + e);
        }
        if (choice == 'Y' || choice == 'y'){
            System.out.println("What is your custom phrase");
            try{
        this.phrase = input.nextLine();
            }
             catch(Exception e){
            System.out.println("error of type" + e);
        }
        }
        else{
            
                
            
            Random rand = new Random();
            int z = rand.nextInt(phrases.size());
            this.phrase = phrases.get(z);
            System.out.println("Ok, lets Start!");
            
        }
        
        // for each character in the phrase, create a letter and add to letters array
        for (int i = 0; i < phrase.length(); i++) {
            allLetters.add(new Letter(phrase.charAt(i)));
        }
        
        // setup done
        
       
    
    }
    /**
     * prompt if user wants to change number of Players
     */
    private void playerChange(){
        Scanner input = new Scanner(System.in);
        boolean flag = true;
        
        
        while(flag){
            System.out.println("add a player(A) or remove a player enter (R) or (E) to exit and continue playing ");
            
            char choice = 'a';
        try{
            
        
        choice = input.next().charAt(0);
        input.nextLine();
        }
         catch(Exception e){
            System.out.println("error of type" + e);
        }
        boolean trip = true;
        while(trip){
            if(choice == 'A' || choice == 'a'){
                trip = add();
            }
            else if (choice == 'R' || choice == 'r'){
                trip = remove();
            }
            else if(choice == 'e' || choice == 'E'){
                flag = false;
                break;
            }
            else{
                System.out.println("please enter A from adding a player and R for removing one and E to exit");
            }
        }
        }
    }
    
    /**
     * logic for user to add player after initial initialization
     * @return 
     */
    private boolean add(){
        Scanner input = new Scanner(System.in);
        System.out.println("What is the new players name?");
            String name;
            //FIXME exectutes immedietly
        //FIXME no way to use nextLine
        try{
            name = input.nextLine();
        
            players.add(new Player(name));
        
        
        }
        catch(Exception e){
            System.out.println("error of type" + e);
        }
        
        return false;
        
        
    }
    /**
     * logic for user to remove layer after initial initialization
     * @return 
     */
    private boolean remove(){
        Scanner input = new Scanner(System.in);
        boolean doRun = true;
        while(doRun){
        System.out.println("enter the name of the player you want to remove");{
       
        
                String name = "";
            //FIXME exectutes immedietly
        //FIXME no way to use nextLine
        try{
            name = input.nextLine();
        
            
        
        
        }
        catch(Exception e){
            System.out.println("error of type" + e);
        }
        
        //search for name in players list
        boolean found = false;
        for(Player i: players){
            String tempName;
            tempName = i.getName();
            
            
            
            if (tempName.equalsIgnoreCase(name)){
                players.remove(i);
                System.out.println("The player by the name of " + name + " was removed");
                found = true;
                doRun = false;
                break;
            }
            
        }
        if(!found){
        System.out.println("no Player by that name could be found Please try again");
        }

        
    }
    }
        return false;
    }
    
}