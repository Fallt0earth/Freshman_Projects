/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package woffortune;

/**
 *This class hold prize objects for easy use that the players can win
 * @author dstok
 * 
 * 
 */

public class Prizes {
    private String title;
    private int value;
    
    /**
     * create prize
     * @param title
     * @param value 
     */
    public Prizes(String title, int value) {
        this.title = title;
        this.value = value;
    }
    /**
     * getter
     * @return String title
     */
    public String getTitle() {
        return title;
    }
    
    /**
     * setter
     * @param title 
     */
    public void setTitle(String title) {
        this.title = title;
    }
    /**
     * getter
     * @return value
     */
    
    public int getValue() {
        return value;
    }
    /**
     * setter
     * @param value 
     */
    public void setValue(int value) {
        this.value = value;
    }
    /**
     * returns all fields in the prize object
     * @return String 
     */
    public String printAll(){
        return " " + title + " with a value of " + value + "$";
    }
    
    
    
}
