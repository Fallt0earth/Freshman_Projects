/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package banksim;

import java.util.Scanner;

/**
 *
 * @author David Stokes
 * this is a test harness
 * MY 5 methods are:
 * 
 * ALL IN BANKSIM
 * customerAccountSelect()
 * employeeInterface()
 * accessCustomer()
 * customerInterface()
 * login()
 * 
 * 
 */
public class TestHarness {
    
    
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        BankSim bank = new BankSim();
        boolean flag = true;
        while(flag){
        
       User currentUser = bank.login();
       
       String current = currentUser.getClass().toString();
       
       
       current = current.substring(14, current.length());
       
          
       
       //customer login
       if(current.equals("Customer")){
       bank.customerInterface((Customer)currentUser);
       }
       //employee logged in
       else{
           bank.employeeInterface((Employee)currentUser);
       }
       
            System.out.println("would you like to |continue| or |power down|");
            
            String pick = input.nextLine();
            
            if(pick.equalsIgnoreCase("power down")){
                System.out.println("powering down, goodbye");
                System.exit(0);
            }
            else{
                System.out.println("continuing");
            }
       
       
        
        
        
   
    }
    }
    
}
