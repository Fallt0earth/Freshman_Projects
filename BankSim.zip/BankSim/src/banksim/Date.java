/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package banksim;

/**
 *
 * @author David Stokes
 * used for simulating time progression
 */
public class Date {
    private int day;
    private int month;
    private int year;

    public Date(int day, int month, int year) {
        this.day = day;
        this.month = month;
        this.year = year;
    }

    public int getDay() {
        return day;
    }

    public void setDay(int day) {
        this.day = day;
    }

    public int getMonth() {
        return month;
    }

    public void setMonth(int month) {
        this.month = month;
    }

    public int getYear() {
        return year;
    }

    public void setYear(int year) {
        this.year = year;
    }
    
    @Override
    public String toString(){
        return (month + "/" + day + "/" + year);
    }
    /**
     * simulate the advancement of time
     * @param days
     * @return 
     */
    public Date advanceTime(int days){
        for (int i = 0; i < days; i++) {
            //represtns overflowing of day into months etc
            if(day == 30){
                this.day = 1;
                
              
                if(month == 12){
                    this.year++;
                    this.month = 1;
                }
                else{
                    month++;
                }
            }
                else{
                      this.day++;
                        }
                
              
            }
        
            
        
        return this;
    }
    
}
