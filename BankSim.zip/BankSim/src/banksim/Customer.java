/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package banksim;


import java.util.ArrayList;

/**
 *
 * @author David Stokes
 * customer user type
 */
public class Customer extends User {
    private ArrayList<Account> accounts = new ArrayList<>();
    private String address;
    private String cellPhone;
    private String citizenship;
    private String userName;
    private String password;
    private BankSim bank;

    public Customer(ArrayList<Account> accounts, String address, String cellPhone, String citizenship, String userName, String password, String firstName, String lastName, int socialSecurity, int age, String email) {
        super(firstName, lastName, socialSecurity, age, email);
        this.accounts = accounts;
        this.address = address;
        this.cellPhone = cellPhone;
        this.citizenship = citizenship;
        this.userName = userName;
        this.password = password;
    }
    /**
     * constructor for a new customer who does not have any accounts
     * @param address
     * @param cellPhone
     * @param citizenship
     * @param userName
     * @param password
     * @param firstName
     * @param lastName
     * @param socialSecurity
     * @param age
     * @param email
     * @param x 
     */
    public Customer(String address, String cellPhone, String citizenship, String userName, String password, String firstName, String lastName, int socialSecurity, int age, String email, BankSim x) {
        super(firstName, lastName, socialSecurity, age, email);
       
        this.address = address;
        this.cellPhone = cellPhone;
        this.citizenship = citizenship;
        this.userName = userName;
        this.password = password;
        this.bank = x;
        
        initialize();
    }

    public ArrayList<Account> getAccounts() {
        return accounts;
    }

    public void setAccounts(ArrayList<Account> accounts) {
        this.accounts = accounts;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getCellPhone() {
        return cellPhone;
    }

    public void setCellPhone(String cellPhone) {
        this.cellPhone = cellPhone;
    }

    public String getCitizenship() {
        return citizenship;
    }

    public void setCitizenship(String citizenship) {
        this.citizenship = citizenship;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }
 
    private void initialize(){
        accounts.add(new Saving(1, .01, 6, "one",  10000, 20, false, bank.overAllDate, 30));
         accounts.add(new Saving(0, .02, 6, "two", 10000, 100, false, bank.overAllDate, 30));
          accounts.add(new Saving(1, .001, 6, "three", 100000, 1000, false, bank.overAllDate, 30));
          accounts.add(new Checking(10, .001, "four", 800, 1, true, bank.overAllDate, 70));
                  
    }
    
                  
    
}
