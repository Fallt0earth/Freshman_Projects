/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package banksim;

/**
 *
 * @author David Stokes
 * the superclass of all Accounts
 */
public abstract class Account {

    private String name;
    private double balance;
    private double minimumBalance;
    private boolean ATMAccess;
    private Date dateCreated;
    private double monthlyFee;

    public Account(String name, double balance, double minimumBalance, boolean ATMAccess, Date dateCreated, double monthlyFee) {
        this.name = name;
        this.balance = balance;
        this.minimumBalance = minimumBalance;
        this.ATMAccess = ATMAccess;
        this.dateCreated = dateCreated;
        this.monthlyFee = monthlyFee;
    }

    public Account(String name, double balance, Date dateCreated) {
        this.name = name;
        this.balance = balance;
        this.minimumBalance = 100;
        this.ATMAccess = true;
        this.dateCreated = dateCreated;
        this.monthlyFee = this.balance * .0001;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
    
    //all accounts should simulate interest
    public abstract void interestCalc(Date start, Date current);

    public double getBalance() {
        return balance;
    }

    public void setBalance(double balance) {
        this.balance = balance;
    }

    public double getMinimumBalance() {
        return minimumBalance;
    }

    public void setMinimumBalance(double minimumBalance) {
        this.minimumBalance = minimumBalance;
    }

    public boolean isATMAccess() {
        return ATMAccess;
    }

    public void setATMAccess(boolean ATMAccess) {
        this.ATMAccess = ATMAccess;
    }

    public Date getDateCreated() {
        return dateCreated;
    }

    public void setDateCreated(Date dateCreated) {
        this.dateCreated = dateCreated;
    }

    public double getMonthlyFee() {
        return monthlyFee;
    }

    public void setMonthlyFee(double monthlyFee) {
        this.monthlyFee = monthlyFee;
    }

    public abstract void checkBalance();
    
    /**
     * withdraw money from an account while checking if atm withdrawals are allowed
     * @param remove amount to be withdrawn from account
     */
    public void withdrawal(double remove) {
        //check if atm access is enabled for account type
        if (ATMAccess) {
            //ensure positive integer and remove from account
            if (balance - Math.abs(remove) > 0) {
                balance = this.balance - Math.abs(remove);
            } else {
                System.out.println("Not enough funds");
            }
        } else {
            System.out.println("Sorry, this Account type cannot be accesed using an ATM");
        }
    }
    /**
     * deposits funds into an account
     * @param add amount to be added to account
     */
    public void deposit(double add) {
        if (ATMAccess) {
            //abs prevents shenaningans
            balance = this.balance + Math.abs(add);
        } else {
            System.out.println("Sorry, this Account type cannot be accesed using an ATM");
        }
    }
    /**
     * transfers funds between two of the customers accounts accounts
     * @param receive
     * @param amt 
     */
    public void transfer(Account receive, double amt) {
        //ensure enough funds are present
        if (this.getBalance() > amt) {
            receive.setBalance(receive.getBalance() + amt);
            this.setBalance(balance - amt);
        } else {
            System.out.println("insuffecient funds");
        }
    }

}
