/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package banksim;


/**
 *
 * @author David Stokes
 * contains definitions for checking accounts
 */
public class Checking extends Account {
    private double overDraftFee;
    private double interestRate;

    public Checking(double overDraftFee, double interestRate, String name, double balance, double minimumBalance, boolean ATMAccess, Date dateCreated, double monthlyFee) {
        super(name, balance, minimumBalance, ATMAccess, dateCreated, monthlyFee);
        this.overDraftFee = overDraftFee;
        this.interestRate = interestRate;
    }
    /**
     * alternate constructor for gui based creation
     * @param overDraftFee
     * @param interestRate
     * @param name
     * @param balance
     * @param dateCreated 
     */
    public Checking(double overDraftFee, double interestRate, String name, double balance, Date dateCreated){
        super(name, balance, dateCreated);
        this.overDraftFee = overDraftFee;
        this.interestRate = interestRate;
    }

    

    
    public double getOverDraftFee() {
        return overDraftFee;
    }

    public void setOverDraftFee(double overDraftFee) {
        this.overDraftFee = overDraftFee;
    }

    public double getInterestRate() {
        return interestRate;
    }

    public void setInterestRate(double interestRate) {
        this.interestRate = interestRate;
    }
    /**
     * calculates interest over a period of time
     * @param start
     * @param current 
     */
       @Override
    public void interestCalc(Date start, Date current){
        double balance = super.getBalance();
        int runs = 0;
        boolean flag = false;
        int remaining = 0;
        
        int yearDiff = current.getYear() - start.getYear();
        int monthDiff = current.getMonth() - start.getMonth();
        int dayDiff =  current.getDay() - start.getDay();
        
        if(yearDiff > 0){
            runs = yearDiff * 365;
        }
        //for the sake of simplicity every month will have 30 days could add addional ifs to handle
        if(monthDiff > 0){
           remaining = 30 - start.getDay();
           
            runs = runs + remaining;
            if(monthDiff > 1){
            runs = runs + ( (monthDiff - 1) * 30);
            flag = true;
            }
    }
        if(dayDiff > 0){
            if(flag){
                 int store = dayDiff - remaining; 
                 runs = runs + store;
            }
            runs = dayDiff;
      }
        //after every day interest is compounded
        for(int i = 0; i < runs; i++){
            balance = balance + (balance * interestRate);
        }
    
        
        
        super.setBalance(balance); 
    }
    @Override
    public  void checkBalance(){
        System.out.printf("Your Checking Account has a balance of $%.2f", this.getBalance());
    }
    
    
    

}