/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package banksim;

import java.util.ArrayList;

/**
 *
 * @author David Stokes
 * employee user type
 */
public class Employee extends User {
    private String position;
    private double salary;
    private Employee manager;
    private ArrayList<Employee> subordinates;
    private String companyPhone;
    private String companyEmail;
    private String userName;
    private String password;

    public Employee(String position, double salary, Employee manager, ArrayList<Employee> subordinates, String companyPhone, String companyEmail, String userName, String password, String firstName, String lastName, int socialSecurity, int age, String email) {
        super(firstName, lastName, socialSecurity, age, email);
        this.position = position;
        this.salary = salary;
        this.manager = manager;
        this.subordinates = subordinates;
        this.companyPhone = companyPhone;
        this.companyEmail = companyEmail;
        this.userName = userName;
        this.password = password;
    }
//does not have subordinates or boss
    public Employee(String position, double salary, String companyPhone, String companyEmail, String userName, String password, String firstName, String lastName, int socialSecurity, int age, String email) {
        super(firstName, lastName, socialSecurity, age, email);
        this.position = position;
        this.salary = salary;
        this.manager = null;
        this.companyPhone = companyPhone;
        this.companyEmail = companyEmail;
        this.userName = userName;
        this.password = password;
    }
    //does not have a manager
    public Employee(String position, double salary, ArrayList<Employee> subordinates, String companyPhone, String companyEmail, String userName, String password, String firstName, String lastName, int socialSecurity, int age, String email) {
        super(firstName, lastName, socialSecurity, age, email);
        this.position = position;
        this.salary = salary;
        this.subordinates = subordinates;
        this.companyPhone = companyPhone;
        this.companyEmail = companyEmail;
        this.userName = userName;
        this.password = password;
    }
    

   

    public String getPosition() {
        return position;
    }

    public void setPosition(String position) {
        this.position = position;
    }

    public double getSalary() {
        return salary;
    }

    public void setSalary(double salary) {
        this.salary = salary;
    }

    public Employee getManager() {
        return manager;
    }

    public void setManager(Employee manager) {
        this.manager = manager;
    }

    public ArrayList<Employee> getSubordinates() {
        return subordinates;
    }

    public void setSubordinates(ArrayList<Employee> subordinates) {
        this.subordinates = subordinates;
    }

    public String getCompanyPhone() {
        return companyPhone;
    }

    public void setCompanyPhone(String companyPhone) {
        this.companyPhone = companyPhone;
    }

    public String getCompanyEmail() {
        return companyEmail;
    }

    public void setCompanyEmail(String companyEmail) {
        this.companyEmail = companyEmail;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }
    
    
    
    
}
