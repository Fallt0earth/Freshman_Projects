/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package banksim;



/**
 *
 * @author David Stokes
 * contains definitions for savings accounts
 * 
 */
public class Saving extends Account {
    private int withdrawalsThisMonth;
    private double interestRate;
    private int monthlyWithdrawalLimit;

    public Saving(int withdrawalsThisMonth, double interestRate, int monthlyWithdrawalLimit, String name, double balance, double minimumBalance, boolean ATMAccess, Date dateCreated, double monthlyFee) {
        super(name, balance, minimumBalance, ATMAccess, dateCreated, monthlyFee);
        this.withdrawalsThisMonth = withdrawalsThisMonth;
        this.interestRate = interestRate;
        this.monthlyWithdrawalLimit = monthlyWithdrawalLimit;
    }
    /**
     * alternative account creation for gui
     * @param withdrawalsThisMonth
     * @param interestRate
     * @param monthlyWithdrawalLimit
     * @param name
     * @param balance
     * @param dateCreated 
     */
     public Saving(int withdrawalsThisMonth, double interestRate, int monthlyWithdrawalLimit, String name, double balance, Date dateCreated){
         super(name, balance, dateCreated);
         this.withdrawalsThisMonth = withdrawalsThisMonth;
        this.interestRate = interestRate;
        this.monthlyWithdrawalLimit = monthlyWithdrawalLimit;
     } 

 

    public int getWithdrawalsThisMonth() {
        return withdrawalsThisMonth;
    }

    public void setWithdrawalsThisMonth(int withdrawalsThisMonth) {
        this.withdrawalsThisMonth = withdrawalsThisMonth;
    }

    public double getInterestRate() {
        return interestRate;
    }

    public void setInterestRate(double interestRate) {
        this.interestRate = interestRate;
    }

    public int getMonthlyWithdrawalLimit() {
        return monthlyWithdrawalLimit;
    }

    public void setMonthlyWithdrawalLimit(int monthlyWithdrawalLimit) {
        this.monthlyWithdrawalLimit = monthlyWithdrawalLimit;
    }
/**
 * calculate interest over time
 * @param start
 * @param current 
 */
    @Override
    
    public void interestCalc(Date start, Date current){
        double balance = super.getBalance();
        int runs = 0;
        boolean flag = false;
        int remaining = 0;
        
        int yearDiff = current.getYear() - start.getYear();
        int monthDiff = current.getMonth() - start.getMonth();
        int dayDiff =  current.getDay() - start.getDay();
        
        if(yearDiff > 0){
            runs = yearDiff * 365;
        }
        //for the sake of simplicity every month will have 30 days could add addional ifs to handle
        if(monthDiff > 0){
           remaining = 30 - start.getDay();
           
            runs = runs + remaining;
            if(monthDiff > 1){
            runs = runs + ( (monthDiff - 1) * 30);
            flag = true;
            }
    }
        if(dayDiff > 0){
            if(flag){
                 int store = dayDiff - remaining; 
                 runs = runs + store;
            }
            runs = dayDiff;
      }    
            balance = balance * Math.pow((1 + interestRate/365), 365 * (runs/365.0));
        
    
        
        
        super.setBalance(balance); 
    }
    /**
     * displays balance
     */
    @Override
    public  void checkBalance(){
        System.out.printf("Your Savings Account has a balance of $%.2f", this.getBalance());
    }
    
    
    
}
