/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package banksim;

/**
 *
 * @author David Stokes
 * contains definitions for CD accounts
 */
public class CD extends Account{
    private Date minWithdrawalDate;
    private final double INTEREST_RATE;
    private double earlyWithdrawalFee;

    public CD(Date minWithdrawalDate, double INTEREST_RATE, double earlyWithdrawalFee, String name, double balance, double minimumBalance, boolean ATMAccess, Date dateCreated, double monthlyFee) {
        super(name, balance, minimumBalance, ATMAccess, dateCreated, monthlyFee);
        this.minWithdrawalDate = minWithdrawalDate;
        this.INTEREST_RATE = INTEREST_RATE;
        this.earlyWithdrawalFee = earlyWithdrawalFee;
    }
    /**
     * alternate constructor for new accounts
     * @param minWithdrawalDate
     * @param INTEREST_RATE
     * @param earlyWithdrawalFee
     * @param name
     * @param balance
     * @param dateCreated 
     */
    public CD(Date minWithdrawalDate, double INTEREST_RATE, double earlyWithdrawalFee, String name, double balance, Date dateCreated){
        super(name, balance, dateCreated);
        this.minWithdrawalDate = minWithdrawalDate;
        this.INTEREST_RATE = INTEREST_RATE;
        this.earlyWithdrawalFee = earlyWithdrawalFee;
    }

    

   

    public Date getMinWithdrawalDate() {
        return minWithdrawalDate;
    }

    public void setMinWithdrawalDate(Date minWithdrawalDate) {
        this.minWithdrawalDate = minWithdrawalDate;
    }

    public double getEarlyWithdrawalFee() {
        return earlyWithdrawalFee;
    }

    public void setEarlyWithdrawalFee(double earlyWithdrawalFee) {
        this.earlyWithdrawalFee = earlyWithdrawalFee;
    }
    
    /**
     *
     * @param start the date at which interest begins to be calculated
     * @param current the date to which interest should be calculated
     */
    @Override
    public void interestCalc(Date start, Date current){
       double balance = super.getBalance();
        int runs = 0;
        boolean flag = false;
        int remaining = 0;
        
        int yearDiff = current.getYear() - start.getYear();
        int monthDiff = current.getMonth() - start.getMonth();
        int dayDiff =  current.getDay() - start.getDay();
        
        if(yearDiff > 0){
            runs = yearDiff * 365;
        }
        //for the sake of simplicity every month will have 30 days could add addional ifs to handle
        if(monthDiff > 0){
           remaining = 30 - start.getDay();
           
            runs = runs + remaining;
            if(monthDiff > 1){
            runs = runs + ( (monthDiff - 1) * 30);
            flag = true;
            }
    }
        if(dayDiff > 0){
            if(flag){
                 int store = dayDiff - remaining; 
                 runs = runs + store;
            }
            runs = dayDiff;
      }
        //after every day interest is compounded
        for(int i = 0; i < runs; i++){
            balance = balance + (balance * INTEREST_RATE);
        }
    
        
        
        super.setBalance(balance); 
    }
    /**
     * displays balance formated
     */
    @Override
    public  void checkBalance(){
        System.out.printf("\nYour CD Account has a balance of $%.2f", this.getBalance());
    }
}
