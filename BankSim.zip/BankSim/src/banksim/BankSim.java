/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package banksim;

import java.util.ArrayList;

/**
 *
 * @author David Stokes
 * represents the main logic of the bank
 */
import java.util.Scanner;

public class BankSim {

    public Date overAllDate = new Date(14, 7, 1999);
    private ArrayList<Customer> customerList = new ArrayList<>();
    private ArrayList<Employee> employeeList = new ArrayList<>();

    /**
     *
     * @return
     */
    public Date getOverAllDate() {
        return this.overAllDate;
    }

    /**
     *
     * @param overAllDate
     */
    public void setOverAllDate(Date overAllDate) {
        this.overAllDate = overAllDate;
    }

    /**
     *
     * @return
     */
    public ArrayList<Customer> getCustomerList() {
        return customerList;
    }

    /**
     *
     * @param customerList
     */
    public void setCustomerList(ArrayList<Customer> customerList) {
        this.customerList = customerList;
    }

    /**
     *
     * @return
     */
    public ArrayList<Employee> getEmployeeList() {
        return employeeList;
    }

    /**
     *
     * @param employeeList
     */
    public void setEmployeeList(ArrayList<Employee> employeeList) {
        this.employeeList = employeeList;
    }

    /**
     *
     */
    public BankSim() {
        initialize();
    }

    /**
     * @param args the command line arguments
     */
    private void initialize() {

        // TODO code application logic here
        //creates 2 customers to start
        Customer one = new Customer("564 Tree ln", "7044566789", "America", "user1", "password1", "will", "Smith", 335681234, 29, "fakeEmail@gmail.com", this);

        Customer two = new Customer("123 Main St", "9801234567", "France", "user2", "password2", "Bob", "Smith", 325466657, 23, "MemeGod@gmail.com", this);

        //create two employees
        Employee testEmployee = new Employee("Teller", 28000, "7048883333", "Ascott@bofa.com", "AScott", "EPWD", "Ann", "Scott", 332456789, 32, "personalEMail@gmail.com");

        Employee testEmployee2 = new Employee("Teller", 24000, "7043482333", "JPrice@bofa.com", "JPrice", "MyPWD", "James", "Price", 332456732, 24, "personalEMail435@gmail.com");

        this.employeeList.add(testEmployee);
        this.employeeList.add(testEmployee2);

        this.customerList.add(one);
        this.customerList.add(two);

    }

    /**
     * simulates the advancements of time
     *
     * @param daysPast time in days that is to be advanced
     */
    public void simulateTime(int daysPast) {

        Date copy = new Date(overAllDate.getDay(), overAllDate.getMonth(), overAllDate.getYear());

        //moves time forward and calculates interest based on this
        overAllDate.advanceTime(daysPast);
        for (Customer i : this.customerList) {
            for (Account j : i.getAccounts()) {
                j.interestCalc(copy, overAllDate);

            }

        }

    }

    /**
     * create customers
     */
    public void initializeCustomers() {
        Customer one = new Customer("564 Tree ln", "7044566789", "America", "user1", "password1", "will", "Smith", 335681234, 29, "fakeEmail@gmail.com", this);

        Customer two = new Customer("123 Main St", "9801234567", "France", "user2", "password2", "Bob", "Smith", 325466657, 23, "MemeGod@gmail.com", this);
    }

    /**
     * Gets the user to log in as employee or customer and proceeds from there
     * and verifies credentials and then returns that specific user
     *
     * @return User the user who logged in is returned either Employee or
     * Customer
     */
    public User login() {
        Scanner input = new Scanner(System.in);
        String username;
        String password;

        boolean flag = true;
        while (flag) {
            System.out.println("Are you an (A)employee or a customer (B)");
            String test = "";
        
                test = input.nextLine();
               

            if (test.equalsIgnoreCase("A")) {
                System.out.println("Please enter your username");
                username = input.nextLine();
                System.out.println("Thank you, Pleases enter your Password");
                password = input.nextLine();
                System.out.println("Thanks, Logging you in...");

                //check through all employees
                for (Employee i : this.employeeList) {
                    if ((i.getUserName()).equals(username) && (i.getPassword().equals(password))) {

                        System.out.println("Your Login was correct Please choose a menu option");
                        return i;

                    }

                }
                System.out.println("inccorect login");
            } else if (test.equalsIgnoreCase("B")){
                System.out.println("Please enter your username");
                username = input.nextLine();
                System.out.println("Thank you, Pleases enter your Password");
                password = input.nextLine();
                System.out.println("Thanks, Logging you in...");
                boolean correct = false;

                //check through all customers
                for (Customer i : this.customerList) {
                    

                    if ((i.getUserName()).equals(username) && (i.getPassword().equals(password))) {
                        correct = true;

                        System.out.println("Your Login was correct Please choose a menu option");
                        return i;
                    }

                }
                System.out.println("incorrect login");
            } else {
                System.out.println("incorrect input try again");
            }

        }
        return null;
    }

    /**
     * displays customers interface upon succesful login
     *
     * @param i
     * @return
     * @see login()
     */
    public int customerInterface(Customer i) {
        Scanner input = new Scanner(System.in);
        kill:
        while (true) {
            System.out.println("Hello " + i.getFirstName());

            customerMenu();

            String choice = input.next();

            switch (choice) {
                case "1":
                    Account working = customerAccountSelect(i);

                    System.out.println("thank you for your selection, you have acessed your Account named " + working.getName());
                    boolean flag = true;
                    outer:
                    while (flag) {
                        System.out.println("\n1: Check Balance");
                        System.out.println("2: Withdrawal");
                        System.out.println("3: Deposit");
                        System.out.println("4: Transfer");
                        System.out.println("5: Exit");

                        String pick = input.next();

                        switch (pick) {
                            //balance
                            case "1":
                                working.checkBalance();

                                break;
                            //withdraw
                            case "2":
                                System.out.println("How much would you like to withdraw");
                                double x = input.nextDouble();

                                working.withdrawal(x);
                                working.checkBalance();
                                break;
                            //deposit
                            case "3":
                                System.out.println("How much would you like to deposit");
                                double z = input.nextDouble();
                                input.nextLine();

                                working.deposit(z);
                                working.checkBalance();
                                break;
                            case "4":
                                //transfer
                                boolean test = true;

                                while (test) {
                                    System.out.println("What is the name of the account you would like to transfer funds to?");

                                    String lookup = input.nextLine();

                                    Account now = null;
                                    for (Account a : i.getAccounts()) {
                                        if (a.getName().equals(lookup)) {
                                            now = a;
                                            test = false;
                                            break;
                                        }
                                    }

                                    if (test) {
                                        System.out.println("No account of that name found");

                                    } else {
                                        System.out.println("how much would you like transfer?");

                                        double transfer = input.nextDouble();

                                        working.transfer(now, transfer);
                                        working.checkBalance();
                                        now.checkBalance();
                                    }
                                }

                                break;
                            case "5":
                                System.out.println("exiting");
                                break outer;
                            
                            default:
                                System.out.println("invalid input");
                        }

                    }
                    break;

                case "2":
                    //access customer info
                    accessCustomer(i);
                    break;
                case "3":
                    System.out.println("goodbye");
                    
                    break kill;

                case "4":
                    //simulates time passing an interest accruing
                    System.out.println("please enter time passed in days");

                    int y = input.nextInt();

                    simulateTime(y);

            }

        }
        return 0;

    }

    /**
     * displays menu for customer
     */
    public void customerMenu() {
        System.out.println("MENU: Please select and option");
        System.out.println("1: Select Account");
        System.out.println("2: Change info");
        System.out.println("3: Logout");
        System.out.println("4: FOR TESTING SIMULUATE INTEREST");
    }

    /**
     * select bank account from a customers account
     *
     * @param i
     * @return
     */
    public Account customerAccountSelect(Customer i) {
        Scanner input = new Scanner(System.in);
        int flag = 1;
        int counter = 0;
        for (Account j : i.getAccounts()) {
            System.out.println("option: " + (flag++) + j.getClass().toString().substring(13, j.getClass().toString().length() - 1) + " Account named: " + j.getName());
            counter++;
        }
        while (true) {

            System.out.println("Please enter the option you want");
            int choice = input.nextInt();

            input.nextLine();

            if (choice > counter) {
                System.out.println("error you tried to access an account that does not exist");
            } else {

                return i.getAccounts().get(choice - 1);
            }
        }

    }

    /**
     * displays the employee options upon succesful login
     *
     * @param i
     */
    public void employeeInterface(Employee i) {
        Scanner input = new Scanner(System.in);

        while (true) {
            System.out.println("Hello " + i.getFirstName());

            System.out.println("would you like to create a (A)new customer, (B)select an existing one, or (C)logout?");

            char choice = input.next().charAt(0);
            Customer selection = null;

            if (choice == 'A' || choice == 'a') {
                System.out.println("okay, please input the fields requested");

                newCustomer x = new newCustomer(this);
                x.setVisible(true);

                System.out.println("Confiming your input, Press any key");
                //breaks if i take it out
                input.nextLine();
                String useless = input.nextLine();

                selection = this.customerList.get(this.customerList.size() - 1);

                System.out.println("new Customer named: " + (this.customerList.get(customerList.size() - 1)).getFirstName() + " added");
                

                //customerList.add();
            } else if (choice == 'B' || choice == 'b') {
                boolean flag = true;
                while(flag){
                System.out.println("what is the customers social");
                int social = Integer.parseInt(input.next());
                input.nextLine();

                for (Customer k : this.customerList) {

                    if (k.getSocialSecurity() == social) {
                        selection = k;
                        flag = false;

                    }
                }
                if(flag){
                    System.out.println("no customer with that social found please try again");
                }

                }

            }
            else if(choice == 'C' || choice == 'c'){
                System.out.println("logging out, goodbye");
                break;
            }
            boolean run = true;
            while (run) {
                System.out.println("A. Access Customer info");
                System.out.println("B. Acccess Customer Accounts");
                System.out.println("C. Create new Account");
                System.out.println("Exit");

                String pick = input.nextLine();

                if (pick.equals("A")) {
                    accessCustomer(selection);

                } else if (pick.equals("B")) {
                    Account current = customerAccountSelect(selection);

                    employeeAccountAccess(current);

                } else if (pick.equals("C")) {
                    openAccount x = new openAccount(this, selection);
                    x.setVisible(true);

                    input.nextLine();
                    System.out.println("Please press any button to continue");
                    String z = input.nextLine();

                } else if (pick.equals("Exit")) {
                    System.out.println("exiting");
                    break;
                } else {
                    System.out.println("try again");
                }

                
            }
        }

    }

    /**
     *
     * @param Cutomer object j
     * @return used to break out
     */
    private void accessCustomer(Customer j) {
        Scanner input = new Scanner(System.in);

    
        String choice = "";
        boolean flag = true;
        while (flag) {
            System.out.println("please select a menu option, please use upper case");

            accessMenu();

            choice = input.nextLine();

            switch (choice) {
                case "A":
                    System.out.println(j.getFirstName());
                    System.out.println("Please input the new field");
                    j.setFirstName(input.nextLine());
                    System.out.print("new: ");
                    System.out.println(j.getFirstName());
                    break;

                case "B":
                    System.out.println(j.getLastName());
                    System.out.println("Please input the new field");
                    j.setLastName(input.next());
                    System.out.print("new: ");
                    System.out.println(j.getLastName());
                    break;

                case "C":
                    System.out.println(j.getUserName());
                    System.out.println("Please input the new field");
                    j.setUserName(input.nextLine());
                    System.out.print("new: ");
                    System.out.println(j.getUserName());
                    break;
                case "D":
                    System.out.println(j.getPassword());
                    System.out.println("Please input the new field");
                    j.setPassword(input.nextLine());
                    System.out.print("new: ");
                    System.out.println(j.getPassword());
                    break;

                case "E":
                    System.out.println(j.getAddress());
                    System.out.println("Please input the new field");
                    j.setAddress(input.nextLine());
                    System.out.print("new: ");
                    System.out.println(j.getAddress());

                    break;

                case "F":
                    System.out.println(j.getCellPhone());
                    System.out.println("Please input the new field");
                    j.setCellPhone(input.nextLine());
                    System.out.print("new: ");
                    System.out.println(j.getCellPhone());
                    break;

                case "G":
                    System.out.println(j.getCitizenship());
                    System.out.println("Please input the new field");
                    j.setCitizenship(input.nextLine());
                    System.out.print("new: ");
                    System.out.println(j.getCitizenship());
                    break;

                case "H":
                    System.out.println(j.getEmail());
                    System.out.println("Please input the new field");
                    j.setEmail(input.nextLine());
                    System.out.print("new: ");
                    System.out.println(j.getEmail());
                    break;
                case "Exit":
                    System.out.println("exiting");
                    flag = false;
                    break;

                default:
                    System.out.println("incorrect input try again");

                    break;

            }

        }

    }

    private void accessMenu() {
        System.out.println("Change:\t");
        System.out.println("A. first name");
        System.out.println("B. last name");
        System.out.println("C. username");
        System.out.println("D. password");
        System.out.println("E. address");
        System.out.println("F. cell");
        System.out.println("G. citizenship");
        System.out.println("H. email");
        System.out.println("Exit");
    }

    private void employeeAccountAccess(Account k) {
        Scanner input = new Scanner(System.in);
        k.checkBalance();
        String pick = null;

        while (true) {
            System.out.println(": change balance: |Add| or |Sub| or Exit");
            pick = input.next();

            if (pick.equals("Add")) {
                System.out.println("how much");
                double change = input.nextDouble();
                k.setBalance(k.getBalance() + Math.abs(change));
                k.checkBalance();

            } else if (pick.equals("Sub")) {
                System.out.println("how much");
                double change = input.nextDouble();
                k.setBalance(k.getBalance() - Math.abs(change));
                k.checkBalance();
            } else if (pick.equals("Exit")) {
                break;
            } else {
                System.out.println("incorrect input");
            }

        }
    }
}
